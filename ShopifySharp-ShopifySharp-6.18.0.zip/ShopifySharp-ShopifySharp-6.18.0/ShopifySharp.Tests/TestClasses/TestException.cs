#nullable enable
using System;

namespace ShopifySharp.Tests.TestClasses;

public class TestException : Exception;
