// ReSharper disable once CheckNamespace
namespace ShopifySharp;

public enum RequestContext
{
    Foreground,
    Background
}
