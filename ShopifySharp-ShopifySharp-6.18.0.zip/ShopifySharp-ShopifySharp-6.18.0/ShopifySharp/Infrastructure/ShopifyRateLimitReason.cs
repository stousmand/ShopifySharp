namespace ShopifySharp;

public enum ShopifyRateLimitReason
{
    BucketFull,
    Other
}