[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("ShopifySharp.Tests")]
// DynamicProxyGenAssembly2 is NSubstitute
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("DynamicProxyGenAssembly2")]
