namespace ShopifySharp.Filters;

public class UserListFilter : ListFilter<User>
{
}