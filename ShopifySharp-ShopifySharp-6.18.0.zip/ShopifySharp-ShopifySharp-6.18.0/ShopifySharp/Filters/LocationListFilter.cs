namespace ShopifySharp.Filters;

public class LocationListFilter : ListFilter<Location>
{
}