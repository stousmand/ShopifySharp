namespace ShopifySharp.Filters;

public class ApplicationCreditListFilter : ListFilter<ApplicationCredit>
{
}