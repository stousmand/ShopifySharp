namespace ShopifySharp.Entities;

/// <summary>
/// An object representing the Shopify Return
/// </summary>
public class Return : ShopifyObject
{
}