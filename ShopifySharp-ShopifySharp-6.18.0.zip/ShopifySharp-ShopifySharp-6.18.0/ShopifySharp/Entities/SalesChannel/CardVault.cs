using Newtonsoft.Json;

namespace ShopifySharp.Entities.SalesChannel;

public class CardVault
{
    [JsonProperty("id")]
    public string Id { get; set; }
}