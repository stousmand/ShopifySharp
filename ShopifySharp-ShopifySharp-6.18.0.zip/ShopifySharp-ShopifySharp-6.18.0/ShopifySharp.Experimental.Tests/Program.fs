module Program = let [<EntryPoint>] main _ = 0
